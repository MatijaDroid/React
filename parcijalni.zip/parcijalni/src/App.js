import React from 'react';
import Input from './Components/Input';

function App() {
	return (
		<div>
			<Input  />
			
		</div>
	);
}

export default App;

// chat scaledrone ! 
// 2mj. neki rok
// 