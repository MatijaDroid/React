import React, { Component } from 'react'

 class Input extends Component {


    constructor(props)
    {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: null,
            value: null
        }
    }

    handleFetch({value})
    {
        console.log(this.props.value)
        fetch(`https://cors-anywhere.herokuapp.com/https://github.com/${userName}`)
        .then(response => response.json())
        .then(
            (data) => {
                this.setState({
                    isLoaded: true,
                    data,
                    error: data.error
                });
                },
                (error) => {
                this.setState({
                    isLoaded: true,
                    error
                });
            }
        )
    }


    render() {

        const { error, isLoaded } = this.state;

        if(error){
        return <div>Error: {error.message}</div>;
        }else if(!isLoaded){
        return <div>Loading...</div>;
        }else {
            return(
                <div>
                    <form >
                        <label>
                            User search:
                            <input type="text" value={this.props.value} onChange={(value) => {this.handleFetch(value)}}/>
                        </label>
                        <button type="submit">Search</button>
                    </form>
                </div>
            )
        }
    }
}
export default Input;