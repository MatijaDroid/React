import React from 'react'

 function Output() {
    return (
        <div>
            
        </div>
    )
}
export default Output;